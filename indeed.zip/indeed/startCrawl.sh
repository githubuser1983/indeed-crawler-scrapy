#!/bin/sh
cd /home/orges/scrapy/indeed/
ua="$(shuf -n 1 /home/orges/scrapy/userAgents.txt)"
/home/orges/.local/bin/scrapy crawl $1 -s USER_AGENT="$ua"
