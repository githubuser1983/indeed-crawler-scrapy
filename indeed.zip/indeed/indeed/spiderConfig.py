# Vorgehensweise Spider S_i:
# Jedes Item mit URL, hash, JuicyText etc. wird in eine Zeile in die CSV - Datei dirTmpScrapy/{spiderName}/{spiderName}_currentDownload.csv geschrieben. Dabei wird jedes Item am Ende der Datei angehaengt.
# Falls die Datei N = 10.000 Eintraege hat, dann wird die CSV-Datei gezipped mit Namen: {spiderName}_{aktuelleUhrzeitBeimZippen}.zip und:
# Es wird probiert die zip-Datei nach dirExtScrapy zu verschieben. -> Falls das nicht klappt (weil z.B die externe Festplatte nicht gemountet wurde oder so), 
# wird die zip-Datei nach dirIntScrapy verschoben.
# Jeder Spider S_i kann zu unterschiedlichen Zeiten aufgerufen werden und unterschiedlich viele Items herunterladen: Z.B. 
# S_1: Montag     100 Items
# S_1: Dienstag 5.000 Items
# S_1: Mittwoch 6.000 Items 
#-> Hier wird die aktuelle csv-Datei in zip verpackt wenn N=10.000 Items erreicht wurden. 
#   Die restlichen 1.100 Items werden wieder in S_1_currentDownload.csv geschrieben, allerdings wird die Datei ueberschrieben von Anfang an.
# Zaehlung der CSV-Datei:
#   Spider startet: zaehlt seine tmp-csv Datei mit bufcount. Solange der Spider online ist und items herunterlaedt, zaehlt er mit einem internen
#   Zaehler "counterLines" wieviele Zeilen schon in die tmp-csv geschrieben wurden. Falls counterLines = 10.000 -> dann wird die tmp-csv Datei wie oben beschrieben verpackt.
#   "counterLines" wird wieder auf 0 gesetzt.

import os,csv

MaxNumberInCsv = 1000
dirExtScrapy = "/media/orges/f787f79b-6e46-4093-b37c-7287cf65e584/scrapy/"
dirIntScrapy = "/home/orges/scrapy/"
dirTmpScrapy = "/home/orges/scrapy/tmp/"

# https://stackoverflow.com/questions/273192/how-can-i-safely-create-a-nested-directory
def ensure_dir(file_path):
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)

# https://stackoverflow.com/a/850962
def bufcount(filename):
    """ Count the number of lines in a file and return it.
    """
    try:
        f = open(filename)                  
    except:
        return 0
    lines = 0
    csvreader = csv.reader(f,dialect=csv.excel)
    for line in csvreader:
        lines += 1
    return lines

# https://www.programiz.com/python-programming/datetime/current-datetime
def getNow():
    """ Returns the current date and time in the format "%d-%m-%Y_%H:%M:%S" as a string. 
    """
    from datetime import datetime
    # datetime object containing current date and time
    now = datetime.now()
    dt_string = now.strftime("%d-%m-%Y_%H:%M:%S")
    return dt_string 