# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import datetime,logging,os
import csv,zipfile
from indeed import spiderConfig
from shutil import copyfile

class CsvStorePipeline(object):

    def __init__(self,settings):
        self.settings = settings
        self.dirExtScrapy = spiderConfig.dirExtScrapy
        self.dirIntScrapy = spiderConfig.dirIntScrapy 
        self.dirTmpScrapy = spiderConfig.dirTmpScrapy
        self.myhashes = set([])
        self.MaxNumberInCsv = spiderConfig.MaxNumberInCsv
        thisfilepath = os.path.dirname(__file__)
        logging.basicConfig(filename=os.path.join(thisfilepath,"log.txt"), level=logging.DEBUG, format = '%(asctime)s %(message)s')

    # example: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
    def open_spider(self, spider):

        self.spiderName = spider.name
        self.tmpDirName = self.dirTmpScrapy + "/" + self.settings["BOT_NAME"] + "/"+self.spiderName+"/"
        self.tmpCsvName = self.tmpDirName + self.spiderName+"_currentDownload.csv"
        spiderConfig.ensure_dir(self.tmpDirName)
        self.currentCounter = spiderConfig.bufcount(self.tmpCsvName)
        self.tmpCsvFile = open(self.tmpCsvName,"a")
        self.tmpCsvWriter = csv.writer(self.tmpCsvFile,dialect=csv.excel)

    def close_spider(self, spider):
        self.tmpCsvFile.close()

    @classmethod
    def from_crawler(cls, crawler):
        settings = crawler.settings
        return cls(settings)

    def process_item(self, item, spider):
        # run db query in thread pool
        print( 'process item:----------------------')
        logging.info("processing item with url:"+item["url"])
        print( item["url"])
        if item['hash'] in self.myhashes:
          print( "item already seen")
          logging.info("already seen item with url in this crawl:"+item["url"])
        else:
          print( "item not seen")
          logging.info("not seen item with url in this crawl:"+item["url"])
          self.myhashes.add(item['hash'])
          self.insertItem(item)
        return None

    def insertItem(self,item):
        print(item)
        fieldsOfItem = sorted(item.fields.keys())
        #foI = ",".join([eval( ("self.safeValue(item['%s'])" % field) ) for field in fieldsOfItem])
        st = []
        for field in fieldsOfItem:
            x = item[field]
            x = x.replace("\n","")
            st.append(x)
        if self.currentCounter < self.MaxNumberInCsv:
            self.tmpCsvWriter.writerow(st)
            self.currentCounter += 1
        elif self.currentCounter == self.MaxNumberInCsv:
            try: # try to copy , without zip first, to external drive
                spiderConfig.ensure_dir(self.dirExtScrapy + "/" + self.settings["BOT_NAME"]+"/"+self.spiderName+"/")
                dst = self.dirExtScrapy + "/" + self.settings["BOT_NAME"]+"/"+self.spiderName+"/"+self.spiderName + "_"+spiderConfig.getNow()+".csv"
                copyfile(self.tmpCsvName,dst)
            except: # copy to internal directory:
                spiderConfig.ensure_dir(self.dirIntScrapy + "/" + self.settings["BOT_NAME"]+"/")
                dst = self.dirIntScrapy + "/" + self.settings["BOT_NAME"]+"/"+self.spiderName+"/"++self.spiderName + "_"+spiderConfig.getNow()+".csv"
                copyfile(self.tmpCsvName,dst)
            # write zip
            with zipfile.ZipFile(dst+'.zip', 'w') as myzip:
                myzip.write(dst)
            # remove csv-dst:
            os.remove(dst)
            # close current csv-file:
            self.tmpCsvFile.close()
            # delete csv fileit:
            os.remove(self.tmpCsvName)
            self.tmpCsvFile = open(self.tmpCsvName,"a") # reopen it
            self.tmpCsvWriter = csv.writer(self.tmpCsvFile,dialect=csv.excel) # new csv-writer
            self.currentCounter = 0 # reset counter
                                   
