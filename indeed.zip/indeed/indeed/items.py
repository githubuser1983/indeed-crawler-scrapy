# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class JuicyItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    url = scrapy.Field()
    juicyText = scrapy.Field()
    hash = scrapy.Field()
    dateCrawled = scrapy.Field()
    spider = scrapy.Field()
    lastSeen = scrapy.Field()
    email = scrapy.Field()
    title = scrapy.Field()
    company = scrapy.Field()
