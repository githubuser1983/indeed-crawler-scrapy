import scrapy,re

from indeed.items import JuicyItem
import hashlib,datetime,zlib, random

class IndeedSpider(scrapy.Spider):
  name = "indeed"
  # ganz Deutschland : 
  start_urls = ["https://de.indeed.com/Data-Scientist-Jobs"]
  # nur Limburg u Umgebung ( 150 km) :
  #start_urls = ["https://de.indeed.com/Jobs?q=data+scientist&l=Limburg+an+der+Lahn&radius=150"]
  reEmail = re.compile("[a-zA-Z0-9\-\.]+@[a-zA-Z0-9\-\.]+")
  download_delay = 1.0

  baseUrl = "https://de.indeed.com"
  
  reItem = re.compile('href="(/rc/clk[^"]*)"')
  xPathJuicyText = '//*[@id="jobDescriptionText"]' #"/html/body/div[1]/div[2]/div[3]/div/div/div[1]/div[1]"
  #xPathNext = '//*[@id="resultsCol"]/div[39]/a[5]'
  reNext = re.compile('href="(/jobs\?q=Data\+Scientist[^"]+)"')

  def parse(self, response):
    found = 1
    idCounter = 0
    ids = self.reItem.findall(response.text)
    urls = [ self.baseUrl+aidi for aidi in ids]
    print(len(urls))
    #print(urls)
    for url in urls:
        yield scrapy.Request(url,callback=self.parse_item)  
    nextListingsIds = self.reNext.findall(response.text)
    for nextListingId in nextListingsIds:
        nextListingUrl = self.baseUrl + nextListingId
        print(nextListingUrl)
        yield scrapy.Request( nextListingUrl, callback = self.parse )

  def parse_item(self,response):
    juicyText = response.xpath(self.xPathJuicyText).extract_first()
    emails  = self.reEmail.findall(juicyText)
    print(emails)
    if len(emails) > 0:
        item = JuicyItem()
        item['url'] = response.url
        item['juicyText'] = juicyText
        item['hash'] = hashlib.md5(item["juicyText"].encode("utf-8")).hexdigest()
        item['dateCrawled'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        item['spider'] = self.name
        item['lastSeen'] = item['dateCrawled']
        item['email'] = ";".join(emails)
        item['title'] =  response.xpath('/html/body/div[1]/div[2]/div[3]/div/div/div[1]/div[1]/div[1]/h3/text()').extract_first()                 
        item['company'] =response.xpath('/html/body/div[1]/div[2]/div[3]/div/div/div[1]/div[1]/div[1]/div[1]/div/div/div[1]/text()').extract_first()
        if item['company'] is None:
            item['company'] =response.xpath('/html/body/div[1]/div[2]/div[3]/div/div/div[1]/div[1]/div[1]/div[1]/div/div/div[1]/a/text()').extract_first()
        #print(item["company"])
        yield item


