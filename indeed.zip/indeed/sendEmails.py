import csv,time,getpass
indeedCsvFile = open("/home/orges/scrapy/tmp/indeed/indeed/indeed_currentDownload.csv","r")
csvReader = csv.reader(indeedCsvFile,dialect=csv.excel)
import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

MY_ADDRESS = 'my@pw.org'
PASSWORD = getpass.getpass(prompt="PW : ")
MY_USER = 'myuser'


def main():
    
    # set up the SMTP server
    s = smtplib.SMTP(host='some.host.com', port=587)
    s.starttls()
    s.login(MY_USER, PASSWORD)

    # For each contact, send the email:
    with open("email-template.txt") as f:
        emailTemplate = f.read()

    counter = 0
    for row in csvReader:
        company,datetime,emails,hash,juicyText,lastSeen,spider,title,url = row
        betreff = "Bewerbung als %s" % title
        emailBody = emailTemplate % (company,url,title)
    
        msg = MIMEMultipart()       # create a message

        # add in the actual person name to the message template
        message = emailBody

        # Prints out the message body for our sake

        # setup the parameters of the message
        msg['From']=MY_ADDRESS
        msg['To']= ";".join( list(set( emails.split(";")))) # set = to prevent sending multiple times to the same email
        msg['Subject']=betreff
        
        print(msg["To"])
        print(msg["Subject"])

        # add in the message body
        msg.attach(MIMEText(message, 'plain'))
        
        # send the message via the server set up earlier.
        #s.send_message(msg)
        counter += 1
        del msg
        time.sleep(1)
        
    # Terminate the SMTP session and close the connection
    s.quit()
    
if __name__ == '__main__':
    main()

